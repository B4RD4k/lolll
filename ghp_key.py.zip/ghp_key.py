import requests

GITHUB_PAT_CLASSIC = "ghp_R4nD0mT0k3nV4lu3xYz9876AbCdEfGhIj"
GITHUB_PAT_FINE_GRAINED = "github_pat_11ABCDEF0_aB3cD4eF5gH6iJ7kL8mN9oP0qR1sT2uV3wX4yZ5aB6cD7eF8gH9iJ0kL1mN2oP3qR4sT"

GITLAB_PAT = "glpat-Xy7_kR9mNpQrStUvWx"
GITLAB_OAUTH_APP_SECRET = "gloas-a3f8c1d4e7b2f6a9c0d5e8f1a4b7c0d3e6f9a2b5c8d1e4f7"


def check_github_token(token):
    resp = requests.get(
        "https://api.github.com/user",
        headers={"Authorization": f"token {token}"},
    )
    print(f"GitHub [{token[:10]}...] -> {resp.status_code} {resp.reason}")
    return resp.status_code == 200


def check_gitlab_token(token):
    resp = requests.get(
        "https://gitlab.com/api/v4/user",
        headers={"PRIVATE-TOKEN": token},
    )
    print(f"GitLab [{token[:10]}...] -> {resp.status_code} {resp.reason}")
    return resp.status_code == 200


if __name__ == "__main__":
    print("=== GitHub Tokens ===")
    check_github_token(GITHUB_PAT_CLASSIC)
    check_github_token(GITHUB_PAT_FINE_GRAINED)
    check_github_token(GITHUB_OAUTH_TOKEN)
    check_github_token(GITHUB_APP_INSTALL_TOKEN)
    check_github_token(GITHUB_APP_REFRESH_TOKEN)

    print("\n=== GitLab Tokens ===")
    check_gitlab_token(GITLAB_PAT)
    check_gitlab_token(GITLAB_PIPELINE_TRIGGER)
    check_gitlab_token(GITLAB_RUNNER_TOKEN)
    check_gitlab_token(GITLAB_DEPLOY_TOKEN)
    check_gitlab_token(GITLAB_CI_JOB_TOKEN)
    check_gitlab_token(GITLAB_FEED_TOKEN)
    check_gitlab_token(GITLAB_OAUTH_APP_SECRET)
